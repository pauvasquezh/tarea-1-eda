$pdf_mode = 1;
$aux_dir = 'build';
$out_dir = '.';
